# Prime Number Sieve
# https://www.nostarch.com/crackingcodes/ (BSD Licensed)

import math, random

def isPrimeTrialDiv(num):
    # Returns True if num is a prime number, otherwise False.
    # All numbers less than 2 are not prime:
    if num < 2:
        return False

    # See if num is divisible by any number up to the square root of num:
    # TODO

    return True




def generateLargePrime(keysize=1024):
    # Return a random prime number that is keysize bits in size:
    # TODO
    while True:
        a = 2
    return a

